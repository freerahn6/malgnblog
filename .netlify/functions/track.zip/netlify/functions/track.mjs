
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/track.mjs
import { getStore } from "@netlify/blobs";
var track_default = async (req) => {
  const url = new URL(req.url);
  let p = (url.searchParams.get("p") || "/").slice(0, 200);
  if (p.indexOf("/admin") === 0) return new Response(null, { status: 204 });
  const kst = new Date(Date.now() + 9 * 36e5).toISOString().slice(0, 10);
  const store = getStore({ name: "stats", consistency: "strong" });
  for (const key of ["T:" + kst, "P:" + p]) {
    const cur = parseInt(await store.get(key) || "0", 10) + 1;
    await store.set(key, String(cur));
  }
  return new Response(null, { status: 204 });
};
var config = { path: "/api/track" };
export {
  config,
  track_default as default
};
